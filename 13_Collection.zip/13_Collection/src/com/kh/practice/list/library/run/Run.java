package com.kh.practice.list.library.run;

import com.kh.practice.list.library.view.BookMenu;

public class Run {

	public static void main(String[] args) {
		new BookMenu().mainMenu();
	}

}
